﻿namespace TicTacToe.ViewModel
{
    public class UserRegistrationModel
    {
        
        public string? email { get; set; }
        public string? userName { get; set; }
        public string? phoneNumber { get; set; }
        public string? location { get; set; }
        public string? password { get; set; }
       
      
    }
}
